// Dashboard.jsx
import { useNavigate } from "react-router-dom";
import './Dashboard.css';
import Header from './Header';
import Header2 from './Header2';

function Dashboard() {
    const navigate = useNavigate();

    return (
        <div className="dashboard-container">
        </div>
    );
}

export default Dashboard;
